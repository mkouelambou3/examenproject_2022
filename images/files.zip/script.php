<?php 
	$success = null;
	if(isset($_POST['submit'])){
		$success = "Success";
	}
