<?php include "script.php" ?>			
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	 <link rel="stylesheet" href="styles.css">
	<title>How to display error message in html form with javascript</title>
</head>
<body>

	<form name="register-form" action="" method="post" autocomplete="off">
		<label>Enter Username</label>
		<input type="text" name="username">
		<p class="error username-error"></p>
		
		<label>Enter Password</label>
		<input type="text" name="password">
		<p class="error password-error"></p>
	
		<label>Enter email</label>
		<input type="text" name="email">
		<p class="error email-error"></p>
		
		<button type="submit" name="submit">Submit</button>
	
		<p class="success"><?php echo $success ?></p>			
	</form>


	<script src="script.js"></script> <!-- Link to the javascript file -->
</body>
</html>
